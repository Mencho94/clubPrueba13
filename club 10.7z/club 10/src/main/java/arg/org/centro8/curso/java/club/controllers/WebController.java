package arg.org.centro8.curso.java.club.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import arg.org.centro8.curso.java.club.entities.Socio;
import arg.org.centro8.curso.java.club.entities.Entrenador;
import arg.org.centro8.curso.java.club.entities.Actividad;
import arg.org.centro8.curso.java.club.repositories.SocioRepository;
import arg.org.centro8.curso.java.club.repositories.EntrenadorRepository;
import arg.org.centro8.curso.java.club.repositories.ActividadRepository;
import arg.org.centro8.curso.java.club.enums.Dia;
import arg.org.centro8.curso.java.club.enums.Turno;


@Controller
public class WebController {
    
    private ActividadRepository actividadRepository=new ActividadRepository();
    private SocioRepository socioRepository=new SocioRepository();
    private EntrenadorRepository entrenadorRepository=new EntrenadorRepository();
    private String mensajeActividad="Ingrese un nuevo Deporte o Actividad!";
    private String mensajeSocio="Ingrese un nuevo Socio!";
    private String mensajeEntrenador="Ingrese un nuevo Entrenador!";

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

    @GetMapping("/actividad")
    public String getActividad(@RequestParam(name="buscarActividad", required = false, defaultValue="") String buscarNombre,
                                 Model model){
        model.addAttribute("mensajeActividad", mensajeActividad);
        model.addAttribute("actividad", new Actividad());
        //model.addAttribute("actividad", actividadRepository.getAll());
        model.addAttribute("likeNombre", actividadRepository.getLikeNombre(buscarNombre));
        return "actividad";
    }

    @GetMapping("/socio")
    public String getSocio(@RequestParam(name="buscarApellido", required = false, defaultValue="") String buscarApellido,
                    Model model){
        model.addAttribute("mensajeSocio", mensajeSocio);
        model.addAttribute("socio", new Socio());
        model.addAttribute("likeApellido", socioRepository.getLikeApellido(buscarApellido));
        model.addAttribute("actividad", socioRepository.getAll());
        return "socio";
    }

    @GetMapping("/entrenador")
    public String getEntrenador(@RequestParam(name="buscarApellido", required = false, defaultValue="") String buscarApellido,
                    Model model){
        model.addAttribute("mensajeEntrenador", mensajeEntrenador);
        model.addAttribute("entrenador", new Entrenador());
        model.addAttribute("likeApellido", entrenadorRepository.getLikeApellido(buscarApellido));
        model.addAttribute("idActividad", entrenadorRepository.getAll());
        return "entrenador";
    }

    @PostMapping("/saveActividad")
    public String save(@ModelAttribute Actividad actividad){
        try {
            actividadRepository.save(actividad);
            mensajeActividad="Se guardo la Actividad id: "+actividad.getId();
        } catch (Exception e) {
            mensajeActividad="Ocurrio un error";
        }
        return "redirect:actividad";
    }

    @PostMapping("/saveSocio")
    public String save(@ModelAttribute Socio socio){
        try {
            socioRepository.save(socio);
            mensajeSocio="Se guardo el socio id: "+socio.getId();
        } catch (Exception e) {
            mensajeSocio="Ocurrio un error";
        }
        return "redirect:socio";
    }

    @PostMapping("/saveEntrenador")
    public String save(@ModelAttribute Entrenador entrenador){
        try {
            entrenadorRepository.save(entrenador);
            mensajeEntrenador="Se guardo el entrenador id: "+ entrenador.getId();
        } catch (Exception e) {
            mensajeEntrenador="Ocurrio un error";
        }
        return "redirect:entrenador";
    }
}




